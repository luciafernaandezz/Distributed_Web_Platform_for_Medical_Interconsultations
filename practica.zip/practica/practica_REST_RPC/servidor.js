require("./servidor_rest.js")
require("./servidor_rpc.js")
require("./servidor_websocket.js")